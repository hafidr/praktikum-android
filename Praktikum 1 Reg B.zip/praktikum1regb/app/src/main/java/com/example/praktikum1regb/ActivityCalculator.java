package com.example.praktikum1regb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityCalculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
    }
}